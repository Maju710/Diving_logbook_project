﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms; // Reference needs to be added to Diver logbook solution (to System.Windows.Forms)
using System.Xml;
namespace Diver_logbook_project
{
    /// <summary>
    /// Logika interakcji dla klasy Logbook.xaml
    /// </summary>
    public partial class Logbook : Window
    {
        public Logbook()
        {
            InitializeComponent();

            //Viewing XML file functionality (as Message Box)
            System.Windows.Forms.OpenFileDialog ofd = new System.Windows.Forms.OpenFileDialog();
            //Filter for xml files only
            ofd.Filter = "XML | *.xml";
            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)

            {
                XmlDocument XMLLogbook = new XmlDocument();
                XMLLogbook.Load(ofd.FileName);


                LogbookContent.Text = XMLLogbook.SelectSingleNode("DivingLogbook").InnerText;
                

            }

            
            else if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.Cancel)
            {
                //PRoblem

                System.Windows.MessageBox.Show("Logbook direction not specified");
                
            }



        }

       
        
}
}
