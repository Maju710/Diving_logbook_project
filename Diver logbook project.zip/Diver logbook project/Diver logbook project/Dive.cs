﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diver_logbook_project
{
    public abstract class Dive
    {

        //Master class - dive 

        //Default Constructor
        public Dive()
        {
            Description = "Misc. dive";
            Date = "";
            Depth = 0;
            BottomTime = 0;
            WaterVisibility = 2;
            WaterTemperature = 4;
            BuddyName = "Buddy";
            BuddyID = "69";
            BuddyCertification = "Astronaut";
            Equipment = "BCD Wetsuit Computer";
            Weights = 10;
        }
        //Properties
        public string Description { get; set; }
        public string Date { get; set; }
        public int Depth { get; set; }
        public int BottomTime { get; set; }
        public int WaterVisibility { get; set; }
        public int WaterTemperature { get; set; }
        public string BuddyName { get; set; }
        public string BuddyID { get; set; }
        public string BuddyCertification { get; set; }
        public string Equipment { get; set; }
        public int Weights { get; set; }

        // Constructor
        public Dive(string description, string date, int depth, int bottomTime, int waterVisibility, int waterTemperature, string buddyName, string buddyID, string buddyCertification, string equipment, int weights )
        {
            Description = description;
            Date = date;
            Depth = depth;
            BottomTime = bottomTime;
            WaterVisibility = waterVisibility;
            WaterTemperature = waterTemperature;
            BuddyName = buddyName;
            BuddyID = buddyID;
            BuddyCertification = buddyCertification;
            Equipment = equipment;
            Weights = weights;

        }

    }
}
