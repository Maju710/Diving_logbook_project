﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;

namespace Diver_logbook_project
{
    /// <summary>
    /// Logika interakcji dla klasy Load_directory.xaml
    /// </summary>
    public partial class Load_directory : Window
    {
        public Load_directory()
        {
            InitializeComponent();
            //Default directory specified
            LoadDirectory.Text = "C:\\Users\\Jan\\Desktop\\Akademia c#\\Diver logbook project\\XML_logbook.xml";
            
        }
        int DiveDepth;
        int DiveBottomTime;
        int DiveWaterVisibility;
        int DiveWaterTemperature;
        int DiveWeights; 
        private void LoadXML_Click(object sender, RoutedEventArgs e)
        {
            //Some basic "tests"
            bool DepthResult = Int32.TryParse(Depth.Text, out DiveDepth);
            if (DepthResult)
            { }
            else
            {
                MessageBox.Show("Depth should be in an integer format");
            }

            bool BottomTimeResult = Int32.TryParse(BottomTime.Text, out DiveBottomTime);
            if (BottomTimeResult)
            { }
            else
            {
                MessageBox.Show("Bottom Time should be in an integer format");
            }

            bool WaterVisibilityResult = Int32.TryParse(WaterVisibility.Text, out DiveWaterVisibility);
            if (WaterVisibilityResult)
            { }
            else
            {
                MessageBox.Show("Water Vis should be in an integer format");
            }
            bool WaterTemperatureResult = Int32.TryParse(WaterTemperature.Text, out DiveWaterTemperature);
            if (WaterTemperatureResult)
            { }
            else
            {
                MessageBox.Show("Water Temperature should be in an integer format");
            }

            bool DiveWeightsResult = Int32.TryParse(Weights.Text, out DiveWeights);
            if (DiveWeightsResult)
            { }
            else
            {
                MessageBox.Show("Weights should be in an integer format");
            }


            string DiveDescription = Description.Text;
            string DiveDate = Date.Text;
            string DiveBuddyName = BuddyName.Text;
            string DiveBuddyID = BuddyID.Text;
            string DiveBuddyCertification = BuddyCertification.Text;
            string DiveEquipment = Equipment;

            switch (Type.Text)


            {
                //Class instances are created for further development of the app... maybe some dive simulations?
                case "Recreational":
                    Recreational Recreational = new Recreational(DiveDescription, DiveDate, DiveDepth, DiveBottomTime, DiveWaterVisibility, DiveWaterTemperature, DiveBuddyName, DiveBuddyID, DiveBuddyCertification, DiveEquipment, DiveWeights);
                    break;
                case "Work":
                    Work Work = new Work(DiveDescription, DiveDate, DiveDepth, DiveBottomTime, DiveWaterVisibility, DiveWaterTemperature, DiveBuddyName, DiveBuddyID, DiveBuddyCertification, DiveEquipment, DiveWeights);

                    break;
                case "Technical":
                    Technical Technical = new Technical(DiveDescription, DiveDate, DiveDepth, DiveBottomTime, DiveWaterVisibility, DiveWaterTemperature, DiveBuddyName, DiveBuddyID, DiveBuddyCertification, DiveEquipment, DiveWeights);

                    break;
                case "Course":
                    Course Course = new Course(DiveDescription, DiveDate, DiveDepth, DiveBottomTime, DiveWaterVisibility, DiveWaterTemperature, DiveBuddyName, DiveBuddyID, DiveBuddyCertification, DiveEquipment, DiveWeights);

                    break;
            }

           

            string LoadDir = LoadDirectory.Text;
            

            XmlDocument LogbookXML = new XmlDocument();
            LogbookXML.Load(LoadDir);
            XmlNode Dive = LogbookXML.CreateElement("Dive");
            XmlNode Dive_Description = LogbookXML.CreateElement("Dive_Description");
            XmlNode Dive_Depth = LogbookXML.CreateElement("Dive_Depth");
            XmlNode Bottom_Time = LogbookXML.CreateElement("Bottom_Time");
            XmlNode Dive_Type = LogbookXML.CreateElement("Dive_Type");
            XmlNode Dive_Date = LogbookXML.CreateElement("Dive_Date");
            XmlNode Dive_WaterTemperature = LogbookXML.CreateElement("Water_Temperature");
            XmlNode Dive_WaterVisibility = LogbookXML.CreateElement("Water_Visibility");
            XmlNode Dive_Equipment = LogbookXML.CreateElement("Dive_Equipment_And_Configuration");
            XmlNode Dive_Weights = LogbookXML.CreateElement("Dive_Weights");
            XmlNode Buddy_Certification = LogbookXML.CreateElement("Buddy_Certification");
            XmlNode Buddy_ID = LogbookXML.CreateElement("Buddy_ID");
            XmlNode Buddy_Name = LogbookXML.CreateElement("Buddy_Name");

           
            
            //Filling dive node with properties
             Dive_Description.InnerText = "Description: " + Description.Text + "\n";
             Dive_Depth.InnerText = "Depth: " + Depth.Text + "\n";
             Bottom_Time.InnerText = "Bottom Time: " + BottomTime.Text + "\n";
             Dive_Type.InnerText = "Type: "+ Type.Text + "\n";
             Dive_Date.InnerText = "Date: " + Date.Text + "\n";
             Dive_WaterTemperature.InnerText = "Water Temperature: " + WaterTemperature.Text + "\n";
             Dive_WaterVisibility.InnerText = "Water Vis: "+ WaterVisibility.Text + "\n";
             Dive_Equipment.InnerText = "Equipment and config: "+ Equipment + "\n";
             Dive_Weights.InnerText = "Weights: "+Weights.Text + "\n";           
             Buddy_Certification.InnerText = "Buddy Cert: "+BuddyCertification.Text + "\n";
             Buddy_ID.InnerText = "Buddy ID: " + BuddyID.Text + "\n";
            Buddy_Name.InnerText = "Buddy Name: " + BuddyName.Text + "\n" + "\n";
            
            //Appending properties to the dive node
            Dive.AppendChild(Dive_Description);
            Dive.AppendChild(Dive_Depth);
            Dive.AppendChild(Dive_Type);
            Dive.AppendChild(Dive_Date);
            Dive.AppendChild(Dive_WaterTemperature);
            Dive.AppendChild(Dive_WaterVisibility);
            Dive.AppendChild(Dive_Equipment);
            Dive.AppendChild(Dive_Weights);
            Dive.AppendChild(Buddy_Certification);
            Dive.AppendChild(Buddy_ID);
            Dive.AppendChild(Buddy_Name);
            
                                
            if (DepthResult & BottomTimeResult & WaterVisibilityResult & DiveWeightsResult & WaterTemperatureResult)
            {
                LogbookXML.DocumentElement.AppendChild(Dive);
                LogbookXML.Save(LoadDir);
                MessageBox.Show("Dive added to the logbook");
                this.Close();
            }

            else
            {
                MessageBox.Show("Dive couldn't be added");

            }
        }
        public string Equipment;
        public void Checkbox_Checked(object sender, RoutedEventArgs e)
        {

            //Adding ticked equipments to the equipment variable
            Equipment += (string)((CheckBox)sender).Content + " ";

        }

    }
}
