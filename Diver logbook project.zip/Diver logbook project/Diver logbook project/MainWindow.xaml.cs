﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms; // Reference needs to be added to Diver logbook solution (to System.Windows.Forms)
using System.Xml;

namespace Diver_logbook_project
{
    /// <summary>
    /// Logika interakcji dla klasy MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //Tests must be included!!!          
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {      
            //Opening new dive manager                       
            Load_directory LoadWindow = new Load_directory();
            LoadWindow.Show();
   
        }

        private void ViewLogbookButton_Click(object sender, RoutedEventArgs e)
        {

            //Viewing XML file functionality (as Message Box)
           // System.Windows.Forms.OpenFileDialog ofd = new System.Windows.Forms.OpenFileDialog();
            //Filter for xml files only
           // ofd.Filter = "XML | *.xml";
           // if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)

            {
                Logbook LogbookWindow = new Logbook();
                LogbookWindow.Show();
               // XmlDocument Logbook = new XmlDocument();
                //Logbook.Load(ofd.FileName);
                     
                //System.Windows.MessageBox.Show(Logbook.SelectSingleNode("DivingLogbook").InnerText);

            }

        }

        private void Calculator_Click(object sender, RoutedEventArgs e)
        {
            //Calculator's functionality 

            //Odwolania do toolboxa
            Calculator CalculatorWindow = new Calculator();
            CalculatorWindow.Show();
            
        }
        
        private void CreateXML_Click(object sender, RoutedEventArgs e)
        {
            //Saving new XML window
            Save_directory DirectoryWindow = new Save_directory();
            DirectoryWindow.Show();
        }
    }
}