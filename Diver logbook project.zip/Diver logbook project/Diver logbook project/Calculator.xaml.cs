﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Diver_logbook_project


{
    
        
      
    
    public partial class Calculator : Window
    {
        public Calculator()
        {
            InitializeComponent();
        }

        public delegate double CalculatorMethod (double Value);
        


        //Delegated toolbox'es methods inside the clicks

        CalculatorMethod MetersFeet;
        private void MtoF_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                MetersFeet = new CalculatorMethod(Toolbox.MetersToFeetConverter);
                string TextFeet = Convert.ToString(Math.Round(MetersFeet(double.Parse(Distance.Text)), 2));
                Result.Text = TextFeet;
            }

            catch

            {
                MessageBox.Show("Wrong distance format. Must be in double type number. ");
            }
        }

        
        CalculatorMethod FeetMeters;
        private void FtoM_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                FeetMeters = new CalculatorMethod(Toolbox.FeetToMetersConverter);
                string TextMeters = Convert.ToString(Math.Round(FeetMeters(double.Parse(Distance.Text)), 2));
                Result.Text = TextMeters;
            }

            catch

            {
                MessageBox.Show("Wrong distance format. Must be in double type number. ");
            }
        }

        CalculatorMethod CelsiusFahrenheit;
        private void CtoF_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                CelsiusFahrenheit = new CalculatorMethod(Toolbox.CelsiusToFahrenheitConverter);
                string TextFahrenheit = Convert.ToString(Math.Round(CelsiusFahrenheit(double.Parse(Temperature.Text)), 2));
                Result.Text = TextFahrenheit;
            }

            catch
            {
                MessageBox.Show("Wrong temperature format. Must be in double type number. ");
            }

        }

        CalculatorMethod FahrenheitCelsius;
        private void FtoC_Click(object sender, RoutedEventArgs e)   
        {
            try
            {
                FahrenheitCelsius = new CalculatorMethod(Toolbox.FahrenheitToCelsiusConverter);
                string TextCelsius = Convert.ToString(Math.Round(FahrenheitCelsius(double.Parse(Temperature.Text)), 2));
                Result.Text = TextCelsius;
            }

            catch
            {
                MessageBox.Show("Wrong temperature format. Must be in double type number. ");
            }
        }

        
        //Without delegates

        private void CalculatePO2_Click(object sender, RoutedEventArgs e)

        {
            try
            {
                string TextCalcPO2 = Convert.ToString(Math.Round((double.Parse(Depth.Text) / 100) * ((double.Parse(O2Content.Text) / 10) + 1), 2));
                Result.Text = TextCalcPO2;
            }

            catch

            {
                MessageBox.Show("You must fill both Depth and O2 content boxes with appropriate (double) number format.");
            }
        }

        private void CheckAdvice_Click(object sender, RoutedEventArgs e)
        {
            double Value = double.Parse(Result.Text);

            if (Value > 1.4 & Value <= 1.6)

            {
                MessageBox.Show("Your PO2 is at a transition level, dive at your own risk");
            }

            else if (Value <= 1.4)
            {
                MessageBox.Show("Your PO2 is at safe level");
            }

            else if (Value > 1.6)

            {
                MessageBox.Show("PO2 IS TOO HIGH, CNS DISORDER POSSIBLE, LOWER YOUR MAX DEPTH");
            }

            else
            {
                MessageBox.Show("Wrong PO2 value... change O2 content and/or depth");
            }
        }
    }
}
