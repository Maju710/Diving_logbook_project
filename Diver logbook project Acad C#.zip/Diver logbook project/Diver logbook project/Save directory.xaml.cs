﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;

namespace Diver_logbook_project
{
    /// <summary>
    /// Logika interakcji dla klasy Save_directory.xaml
    /// </summary>
    public partial class Save_directory : Window
    {
        public Save_directory()
        {
            InitializeComponent();           
        }

        private void SaveXML_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string Dir = Directory.Text;
                XmlTextWriter xWriter = new XmlTextWriter(Dir, Encoding.UTF8);
                xWriter.Formatting = Formatting.Indented;
                xWriter.WriteStartElement("DivingLogbook");
                xWriter.WriteStartElement("Dive");
                xWriter.WriteStartElement("Property");
                xWriter.WriteEndElement();
                xWriter.WriteEndElement();
                xWriter.WriteEndElement();
                xWriter.Close();
                this.Close();
                MessageBox.Show("XML logbook created");
            }

            catch
            {
                MessageBox.Show("Wrong directory");

            }
        }
    }
}
//"C:\\Users\\Jan\\Desktop\\Akademia c#\\Diver logbook project\\XML_logbook.xml"