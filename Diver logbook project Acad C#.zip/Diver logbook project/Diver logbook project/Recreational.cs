﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diver_logbook_project
{
    class Recreational : Dive
    // Rec dive class
    {
        public Recreational() { }

        public Recreational(string description, string date, int depth, int bottomTime, int waterVisibility, int waterTemperature, string buddyName, string buddyID, string buddyCertification, string equipment, int weights)
        {

            Description = description;
            Date = date;
            Depth = depth;
            BottomTime = bottomTime;
            WaterVisibility = waterVisibility;
            WaterTemperature = waterTemperature;
            BuddyName = buddyName;
            BuddyID = buddyID;
            BuddyCertification = buddyCertification;
            Equipment = equipment;
            Weights = weights;
        }
    }
}
