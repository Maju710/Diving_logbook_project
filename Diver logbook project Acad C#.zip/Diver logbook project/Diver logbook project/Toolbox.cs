﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Diver_logbook_project
{
    static class Toolbox
    {


        public static double MetersToFeetConverter(double Meters)

        {
            double Feet = Meters * 3.28;
            return Feet;

        }

        public static double FeetToMetersConverter(double Feet)

        {
            double Meters = Feet / 3.28;
            return Meters; 

        }

        public static double CelsiusToFahrenheitConverter(double Celsius)

        {
            double Fahrenheit = 1.8 * Celsius + 32;            
            return Fahrenheit;

        }

        public static double FahrenheitToCelsiusConverter(double Fahrenheit)
        {

            double Celsius = (Fahrenheit - 32) / 1.8;
            return Celsius;

        }

        public static double PartialOxygenPressure(double Depth,double O2Content)

        {
            double PartialOxPressure = (Depth / 100) * ((O2Content / 10) + 1);
            return PartialOxPressure;
        }
    }
}
